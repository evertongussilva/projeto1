var marcaVeiculo = "Marca do Veículo";
var anoVeiculo = 2022;
var kmVeiculo = 0;
var valorVeiculo = 102.059;
var valorJuros = 13.500;
var valorDesconto = 5.000;
var numeroParcelas = 24;

console.log(marcaVeiculo);
console.log(anoVeiculo);
console.log(kmVeiculo);
console.log(valorVeiculo);
console.log(valorJuros);
console.log(valorDesconto);
console.log(numeroParcelas);

//adição

var valorVeiculo;
var valorJuros;

valorTotal = valorVeiculo + valorJuros;
console.log(valorTotal);

//subtração

var valorVeiculo;
var valorDesconto;

valorTotal1 = valorVeiculo + valorDesconto;
console.log(valorTotal1);

//multiplicação

var valorVeiculo;

valorTotal2 = valorVeiculo * valorVeiculo;
console.log(valorTotal2);

//exponentition

var valorVeiculo;

valorTotal3 = valorDesconto ** valorVeiculo;
console.log(valorTotal3);

//divisão
 
var valorVeiculo;
var numeroParcelas;

valorTotal4 = valorVeiculo / numeroParcelas;
console.log(valorTotal4);

//Modulo

var valorVeiculo;
var valorJuros;

valorTotal5 = valorVeiculo % valorJuros;
console.log(valorTotal5);

//Incremento

var valorVeiculo;
var valorJuros;

valorTotal6 = valorVeiculo - valorDesconto;
valorTotal6++;

console.log(valorTotal6);